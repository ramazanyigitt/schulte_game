enum GameType {
  ClassicOriginal,
  ClassicOriginalReverse,
  ClassicLight,
  ClassicLightReverse,
  Reaction,
  Memory
}
